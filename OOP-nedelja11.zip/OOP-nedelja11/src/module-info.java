module artikli {
	requires javafx.graphics;
	requires javafx.controls;
	exports comboboxcellfactory;
	exports listviewcellfactory;
	
}