package tabledemo;

public class App {

	public static void main(String[] args) {
		AddItemsTableDemo.main(args);
	}

}
