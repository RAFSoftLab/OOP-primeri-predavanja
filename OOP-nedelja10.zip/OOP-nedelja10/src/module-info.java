module oopjavafxkolekcije {
	requires javafx.graphics;
	requires javafx.controls;
	exports javafxkolekcije;
	exports tabledemo;
	exports colorpicker;
	exports datepicker;
	exports treedemo;
	
}