package objectdemo;


public class ProtectedDemo {
	
	public static void main(String[] args) {
		MojZaposleni mz = new MojZaposleni("Sale", "Kostic");
		mz.ispisiInicicijale();
		
		
	}

}
