package objectdemo;

import nasledjivanjedemo.Nastavnik;

public class ToStringDemo {

	public static void main(String[] args) {
		
		
		Nastavnik n = new Nastavnik("Milos", "Milosevic", "1234567890123");	
		System.out.println(n);
		
		
		
		
	

	}

}
