package nasledjivanjedemo;

public class Asistent extends Nastavnik {

	public Asistent(String ime, String prezime) {
		super(ime, prezime);
		
		
	}

}
