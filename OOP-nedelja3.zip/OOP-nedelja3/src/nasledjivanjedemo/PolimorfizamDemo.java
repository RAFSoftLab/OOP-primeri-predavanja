package nasledjivanjedemo;

import objectdemo.MojZaposleni;

public class PolimorfizamDemo {
	
	
	public static void ispisiOpterecenje(Zaposleni z) {
		if(z instanceof Nastavnik)
			System.out.println(((Nastavnik)z).getBrojCasova());
		else if(z instanceof Sluzbenik)
			System.out.println(((Sluzbenik)z).getBrojRadnihSati());
	}
	
	public static void main(String[] args) {
		
		// polimorfizam - demo
		// polimorfizam - osobina programskog jezika da neka imena  mogu pripadati razlicitim tipovima 
		// polimorfizam u OOP - objekti mogu istovrem eno biti instance različitih klasa
		
		Nastavnik n = new Nastavnik("Petar", "Markovic",152);	 
		ispisiOpterecenje(n);	 // n je instanca klase Nastavnik, ali i klase Zaposleni, zato se može proslediti ovoj metodi
		
		Sluzbenik s = new Sluzbenik("Milica", "Krstic",400);		
		ispisiOpterecenje(s);
		
			
		Zaposleni z = new Nastavnik("Petar", "Markovic",180);	
		ispisiOpterecenje(z);
		
		System.out.println(n instanceof Nastavnik);  // true
		System.out.println(n instanceof Zaposleni);   // true
		System.out.println(z instanceof Nastavnik);  // true
		System.out.println(z instanceof Zaposleni);   // true
		System.out.println(z instanceof Sluzbenik);  // false
		
		
		
		
		Zaposleni[] zaposleni = new Zaposleni[3];
		zaposleni[0] = new Nastavnik("Marko","Markovic",140, "docent");		
		zaposleni[1] = new Sluzbenik("Milica","Mitic",500, "referent");
		zaposleni[2] = new Zaposleni("Milos","Stosic");
		
		for(Zaposleni z1:zaposleni)
			z1.ispisi();	 
		
			
		

	}
	
	
	
	
	
}
